/*******************************************************************
* Proj2.java
* <Alex Eckstein / A Thursday / 4:00>
*
* This program enables users to purchase tickets and totals the costs
*******************************************************************/

import java.text.DecimalFormat;
import java.util.Scanner;


import javax.swing.JOptionPane;


public class Proj2 {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in); //scanner for input
		
		DecimalFormat df = new DecimalFormat("#,000.00");
		String YesOrNo;
		
		String c;  //Strings for input
		String seatType = null;
		String p = null;
		int selectP = 0;
		int selectS = 0;
		int numberOfSeats = 0;
		double totalUT;
		double ticketPrice = 0;
		double parkingPrice = 0;
		double total = 0;
		
		boolean ordering = false;
		
		
		double TAX = 0.0575;
		
		System.out.println("***Welcome to the World Champion Royals 2016 Season Ticketing Application! ***");
		System.out.println("\t\t(Application developed by Alex Eckstein)");
		System.out.println("\t\t\t----CROWNED K.C.! ----- \n");
		System.out.println("Please select one of the Season Ticket Plans listed below:");
		System.out.println("\t1)  Full Season Plan (tickets to all 81 regular season games!)");
		System.out.println("\t2)  Half Season Plan (tickets to 40 regular season games)");
		System.out.println("\t3)  Quarter Season Plan (tickets to 20 regular season games)\n");

		do {
			
			System.out.print("\tSelection: ");
			selectP = s.nextInt();
			
			if(selectP == 1) {
	            	selectP = 81;
	           	c = "FULL Season 81-game plan";
	            	ordering = true;
	            
	            break;
			} else if (selectP == 2) {
	        	selectP = 40;
	        	c = "HALF 40-game plan";
	        	ordering = true;
	            
	            break;
			} else if (selectP == 3) {
	        	selectP = 20;
	        	c = "QUARTER Season 20-game plan";
	        	ordering = true;
	            
	            break;
			} else {
				System.out.println("Invalid. Please enter a number 1-3");
				
			}
		} while(ordering = true);
		
		ordering = false;
        	
		
		System.out.println();
		System.out.println("Please select one of the Seating Options listed below:");
		System.out.println("\t     Seating            Per Game");
		System.out.println("   1)  BATS Crown Club Seats        $235");
		System.out.println("   2)  Diamond Club Box              $95");
		System.out.println("   3)  Dugout Box                    $51");	
		System.out.println("   4)  Dugout Plaza                  $40");
		System.out.println("   5)  Field Box                     $36");
		System.out.println("   6)  Field Plaza                   $28");		
		System.out.println("   7)  Outfield Box                  $26");
		System.out.println("   8)  Hy-Vee Box                    $16\n");
		System.out.println("");
		
		do {
		
		System.out.print("\tSelection: ");
		selectS = s.nextInt();
		
		if(selectS == 1) {
        	selectS = 235;
        	seatType = "BATS Crown Club Seats";
        	
            break;
		} else if(selectS == 2) {
        	selectS = 95;
        	seatType = "Diamond Club Box";
            
            break;
		} else if(selectS == 3) {
        	selectS = 51;
        	seatType = "Dugout Box";
            
            break;
		} else if(selectS == 4) {
        	selectS = 40;
        	seatType = "Dugout Plaza";
        	
            break;
		} else if(selectS == 5) {
        	selectS = 36;
        	seatType = "Field Box";
            
            break;
		} else if(selectS == 6) {
        	selectS = 28;
        	seatType = "Field Plaza";
            
            break;
		} else if(selectS == 7) {
        	selectS = 26;
        	seatType = "Outfield Box";
            
            break;
		} else if(selectS == 8) {
        	selectS = 16;
        	seatType = "Hy-Vee Box";
            
            break;
		} else {
			System.out.println("Invalid. Please enter a number 1-8");
		}	
		
		} while(ordering = true);
        	
        System.out.print("\n\tHow many seats would you like to purchase? ");
        numberOfSeats = Integer.valueOf(s.nextInt());
    
        totalUT = (selectP * selectS * numberOfSeats);
        
        ordering = false;
        
    	System.out.println("\n\tA single parking pass is available for purchase at a discounted rate of $8 pergame (regularly $10).");
    	System.out.println("\t(You will be charge for all games of a given package.)");
        
        	System.out.print("\n\tWould you like to include parking? (Y or N): ");
        	YesOrNo = s.next();
        
        	if(YesOrNo.equalsIgnoreCase("y")) {
        		parkingPrice = (selectP * 8);
        		p = "with Parking";
        		ordering = true;
        	
        	} else if (YesOrNo.equalsIgnoreCase("n")) {
        		parkingPrice = (selectP * 10);
        		p = "without Parking";
        		ordering = true;
        	
        	} else {
        		System.out.println("Invalid. Please enter a Y or N");
				
			}
        
        ticketPrice = (totalUT * TAX);
        total = (totalUT + ticketPrice + parkingPrice);
        
        System.out.println("\n\tYou purchased the " + p + " / " + numberOfSeats + " " + seatType + " " + p);
        System.out.printf("\t   Ticket Total: $" + df.format(totalUT));
        System.out.printf("\n\t   Tax: $" + df.format(ticketPrice));
        System.out.printf("\n\t   Parking: $" + df.format(parkingPrice));
        System.out.printf("\n\t   Grand Total: $" + df.format(total));
        
        
        do {
        
        	System.out.print("\n\n\tConfirm Order (Y or N)? ");
        	YesOrNo = s.next();
        
        	if(YesOrNo.equalsIgnoreCase("y")) {
        		System.out.print("\n\tOrder was confirmed. $" + df.format(total) + " will be charged to the account on file.");
        		ordering = true;
        		break;
        		
        	} else if (YesOrNo.equalsIgnoreCase("n")) {
        		System.out.print("\n\tPurchase cancelled. Re-run the application to reselect tickets.");
        		ordering = true;
        		break;
        		
        	} else {
        		System.out.println("Invalid. Please enter a Y or N");
				
			}
        
        } while(ordering = true);
        
        ordering = false;
        
        System.out.print("\n\n\tWould you like to process another order? ");
        
        do {
        
        YesOrNo = s.next();
        
        if(YesOrNo.equalsIgnoreCase("y")) {
        	System.out.println("\n\n");
        	ordering = true;
    		break;
        	
        } else if (YesOrNo.equalsIgnoreCase("n")) {
        	System.out.print("Thank you for your purchase");
        	System.exit(0);
        	
        } else {
        	System.out.println("Invalid. Please enter a Y or N");
			
		}
        
        } while(ordering = true);
        
	}
}