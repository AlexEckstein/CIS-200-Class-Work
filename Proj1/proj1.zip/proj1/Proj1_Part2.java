 /*******************************************************************
* Project1.java
* <Alex Eckstein / Section 1 1/29/2016/4:00>
*
* This program calculates payments and calculates tax 
*******************************************************************/
import java.util.*;

public class Proj1_Part2
{
	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in); // Scanner for input
		String input;         //Temporary storage for input values
		
		String itemName;
		String itemModel;
		double totalPayment;   //Holds Purchase information
		double totalTax;
		double itemPrice;
		final double TAX_RATE = .0615;  //values declared for tax
		
		//Asks user questions to recieve input for purchase
		System.out.print("What brand of computer do you wish to purchase? ");
		itemName = s.nextLine();	
		
		System.out.print("What model? ");
		itemModel = s.nextLine();
		
		System.out.print("Enter the cost of the computer: $");
		input = s.nextLine();//value for item price
		itemPrice = Double.valueOf(input);
		
		//Equations for payment
		totalPayment = (itemPrice*TAX_RATE) + itemPrice;
		totalTax = totalPayment - itemPrice;
		
		System.out.println("Brand: " + itemName);
		System.out.println("Model: " + itemModel);
		System.out.printf("Sales tax:  %.2f\n", totalTax);
		System.out.printf("Total Cost:  %.2f\n", totalPayment);
		
	}
}