 /*******************************************************************
* Project1.java
* <Alex Eckstein / Section 1 1/29/2016/4:00>
*
* This program calculates payments monthly and in total 
*******************************************************************/
import java.util.*;

public class Proj1_Part1
{
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in); // Scanner for input
		String input;//values declared for input

		//values declared for finance and product cost
		double itemPrice;
		final double FINANCE_RATE = 0.03;  
		double financeMonths = 12;
		double monthlyPayment;
		double totalPayment;   
		double amountFinanced;
		
		// Asks questions and recieves input
		System.out.print("Enter the item to be purchased: ");
		input = s.nextLine();
		char [] itemName = input.toCharArray();
		
		System.out.print("Enter the amount of the purchase: $");
		input = s.nextLine();
		itemPrice = Double.valueOf(input);
		
		// Equations for figuring costs
		totalPayment = (itemPrice*FINANCE_RATE) + itemPrice;
		amountFinanced = totalPayment - itemPrice;
		monthlyPayment = totalPayment/financeMonths;
		
		// Prints finance data
		System.out.printf("Your monthly payment is $%.2f\n", monthlyPayment);
		System.out.printf("Your total payment is $%.2f\n", totalPayment);
		System.out.printf("Amount paid in financing is $%.2f\n", amountFinanced);
		
	}
}