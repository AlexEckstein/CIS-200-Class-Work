//Completed file given as a starter file

public class Point {
	private int x;
	private int y;

	public Point(int newX, int newY) {
		x = newX;
		y = newY;
	} // end 2-arg constructor

	public int getX() {
		return x;
	} // end getX()

	public int getY() {
		return y;
	} // end getY()
	
} // end class