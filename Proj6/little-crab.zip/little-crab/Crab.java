import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)
import java.util.*;

/**
 * This class defines a crab. Crabs live on the beach.
 */

public class Crab extends Animal
{
    private int wormsEaten = 0; 
    private GreenfootImage image1;
    private GreenfootImage image2;
    public Crab(){
        image1 = new GreenfootImage("crab.png");
        image2 = new GreenfootImage("crab2.png");
        setImage(image1);
    }
    public void act()
    {
      /*int N = 15;
      move();
      turn(N);*/
       // turnAtEdge();
       // randomTurn();
        move();
        lookForWorm();
        checkKeyPress();
        long millis = Calendar.getInstance().getTimeInMillis();
        
        if(millis >= 200){
        switchImage();
        millis = 0;
    }
    }
    public void switchImage(){
        if ( getImage() == image1 ){
            setImage(image2);
        }
        else
        {
            setImage(image1);
        }
    }
    /**
    * Check whether a control key on the keyboard has been pressed.
    * If it has, react accordingly.
    */
    public void checkKeyPress(){
         if (Greenfoot.isKeyDown("left")){
            turn(-4);
        }
        
        if (Greenfoot.isKeyDown("right")){
            turn(4);
        }
    }
    // turns animal when on edge of map
    public void turnAtEdge(){
         if ( atWorldEdge() ){
          turn(15);
        }
    }
    //turns animal randomly
    public void randomTurn(){
         if(Greenfoot.getRandomNumber(10) == 1){
          turn( Greenfoot.getRandomNumber(360) );
        }
    }
    // if animal is touching worm, eat it
    public void lookForWorm(){
       
        if ( canSee(Worm.class) )
        {
            eat(Worm.class);
            Greenfoot.playSound("slurp.wav");
            wormsEaten++;
        }
        if (wormsEaten == 8){
            Greenfoot.playSound("fanfare.wav");
            Greenfoot.stop();
        }
    }
}


