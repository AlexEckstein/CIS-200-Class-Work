import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This is a description of the lobster class
 * Lobster live on the beach
 */
public class Lobster extends Animal
{
  public void act()
    {
      /*int N = 15;
      move();
      turn(N);*/
        turnAtEdge();
        randomTurn();
        move();
        lookForCrab();
    }
    // turns animal when on edge of map
    public void turnAtEdge(){
         if ( atWorldEdge() ){
          turn(15);
        }
    }
    //turns animal randomly
    public void randomTurn(){
         if(Greenfoot.getRandomNumber(10) == 1){
          turn( Greenfoot.getRandomNumber(360) );
        }
    }
    // if animal is touching crab, eat it
    public void lookForCrab(){
        if ( canSee(Crab.class) )
        {
            eat(Crab.class);
            Greenfoot.playSound("au.wav");
            Greenfoot.stop();
        }
    }
}
