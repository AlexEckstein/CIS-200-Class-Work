
/*******************************************************************
* proj3part2.java
* <Alex Eckstein / Section A 2/4/2016/4:00>
*
* Part1: This program lets you play against a computer 
*******************************************************************/

import java.util.*;

public class proj3part2 
{	
	private static Scanner s;

	public static void main(String [] args){
		
		int player1Score = 0; //Saves player score
		int player2Score = 0;
		int turnTotal = 0;
		
		boolean playerState = false; //Tracks which player's turn it is 
		boolean gameActive = true;
		int diceRoll = 0;	//Holds random value for roll
		String input = null;
		char rollOrStop;
		final int DICETOTAL = 20;
		
		
		s = new Scanner(System.in);
		
		 Random randomNumbers = new Random();
	
		while(gameActive == true) //while game is active
		{
		
			//while player 1 is rolling
			do{		
				rollOrStop = 'a';
				System.out.println();
				System.out.print("Player 1 turn total is " + turnTotal + ". ");
				System.out.print("Enter (r)oll or (s)top: ");
				input = s.nextLine();
				rollOrStop = input.charAt(0);
				
				if (rollOrStop == 'r' || rollOrStop == 'R'){
					diceRoll = randomNumbers.nextInt(6) + 1;
					turnTotal = diceRoll + turnTotal;
					
				
					if (diceRoll == 1){
						System.out.println("You rolled: " + diceRoll);
						turnTotal = 0;
						playerState = true;
						break;
					}else {
						System.out.println("You rolled: " + diceRoll);
					}
					
				}else if (rollOrStop == 's' || rollOrStop == 'S'){
					player1Score += turnTotal;
					turnTotal = 0;
					playerState = true;
					break;
				}
			
				
			}while(playerState == false); 
			
			//end of player 1 do loop	
			playerState = false;
			System.out.print("Turn over.\n");
			System.out.println("Current score: Player 1 has " + player1Score + ", Computer has " + player2Score);
					
			
			
			if (player1Score >= DICETOTAL)
			{
				System.out.println("Player 1 wins");
				gameActive = false;
				break;
			}			
				
			//while Computer is rolling
			do{
				rollOrStop = 'a';
				System.out.print("\nComputer turn total is: " + turnTotal + ". Computer rolls. \n");
				
				
				rollOrStop = input.charAt(0);
				
				//These if statements make the decisions for the computer 
				if(player2Score < 20 || player1Score > player2Score){
					if(turnTotal < 10){
						rollOrStop = 'r';
					
					
					}else if(turnTotal >= 10 || turnTotal + player2Score >= 20){
						rollOrStop = 's';
					}
					//mechanics for rolling and stopping
					if (rollOrStop == 'r' || rollOrStop == 'R'){
							
						diceRoll = randomNumbers.nextInt(6) + 1;
						turnTotal = diceRoll + turnTotal;
						
			
						if (diceRoll == 1){
							System.out.println("Computer rolled: " + diceRoll);
							turnTotal = 0;
							playerState = true;
							break;
						}
						else {
							System.out.println("Computer rolled: " + diceRoll);
						}
						
					}else if (rollOrStop == 's' || rollOrStop == 'S')
					{
						player2Score += turnTotal;
						turnTotal = 0;
						playerState = true;
						break;
					}
				}//End of computer if statement
				}while(playerState == false);
			
			//end of Computer do loop
			playerState = false;
			System.out.println("Turn over.");
			System.out.print("Current score: Player 1 has " + player1Score + ", Computer has " + player2Score + "\n");
			if (player2Score >= DICETOTAL)
			{
				System.out.println("Computer wins");
				gameActive = false;
				break;
			}
			
		} //end of game while loop
	}//end of main
}// end of class

