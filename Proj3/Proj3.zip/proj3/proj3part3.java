
/*******************************************************************
* proj3part3.java
* <Alex Eckstein / Section A 2/4/2016/4:00>
*
* Part3: This program's main focus is to test the AI of the computer 
* and print the statistics
*******************************************************************/

import java.util.*;

public class proj3part3 
{	
	public static void main(String [] args){
		
		//Saves computer score
		int player2Score = 0;
		int turnTotal = 0; //dice roll total for each turn
		double totalTurns = 0;
		int player1Score = 0;
		double average = 0;
		
		boolean playerState = false; //Tracks which player's turn it is 
		boolean gameActive = true;
		int diceRoll = 0;	//Holds random value for roll
		char rollOrStop = 'a';
		final double DICETOTAL = 20;
		
		int turnsTaken = 0;
		
		 Random randomNumbers = new Random();
	//this loop is used to simulate the program 10 times
	for (int simTotal = 1; simTotal <= 10;){ 
		
		//while game is active
		while(gameActive == true) 
		{
			//while player 1 is rolling
			do{		
				if(player2Score < 20){
					if(turnTotal < 12){
						rollOrStop = 'r';
					}
					
				}else if(turnTotal >= 12 || turnTotal + player2Score >= 20){
						rollOrStop = 's';
					}
				
				if (rollOrStop == 'r' || rollOrStop == 'R'){
					diceRoll = randomNumbers.nextInt(6) + 1;
					turnTotal = diceRoll + turnTotal;
					
				
					if (diceRoll == 1){
						
						turnTotal = 0;
						playerState = true;
						break;
					}else {
						
					}
					
				}else if (rollOrStop == 's' || rollOrStop == 'S'){
					player1Score += turnTotal;
					turnTotal = 0;
					playerState = true;
					break;
				}
			
				
			}while(playerState == false); 
			
			//end of player 1 do loop	
			playerState = false;
						
			
			if (player1Score >= DICETOTAL)
			{
				System.out.println("Player 1 wins");
				gameActive = false;
				break;
			}	
			
				
			//while Computer is rolling
			do{
				rollOrStop = 'a';
				System.out.print("\nComputer turn total is: " + turnTotal);
				
				//These if statements make the decisions for the computer 
				if(player2Score < 20 || player1Score > player2Score){
					if(turnTotal < 10){
						rollOrStop = 'r';
					
					//decides to stop if turn total is greater or = to 10 
					}else if(turnTotal >= 10 || turnTotal + player2Score >= 20){
						rollOrStop = 's';
					}
					//mechanics for rolling and stopping
					if (rollOrStop == 'r' || rollOrStop == 'R'){
							
						diceRoll = randomNumbers.nextInt(6) + 1;
						turnTotal = diceRoll + turnTotal;
						System.out.print(". Computer rolls.\n");
						
			
						if (diceRoll == 1){
							totalTurns++;
							turnsTaken++;
							System.out.println("Computer rolled: " + diceRoll);
							turnTotal = 0;
							playerState = true;
							break;
						}
						else {
							System.out.println("Computer rolled: " + diceRoll);
						}
						
					}else if (rollOrStop == 's' || rollOrStop == 'S')
					{
						totalTurns++;
						turnsTaken++;
						System.out.print(". Computer stops. ");
						player2Score += turnTotal;
						turnTotal = 0;
						playerState = true;
						break;
					}
				}//End of computer if statement
				}while(playerState == false);
			
			//end of Computer do loop
			playerState = false;
			System.out.println("\nTurn over.");
			System.out.print("Current score: Computer has " + player2Score + "\n");
			
			if (player2Score >= DICETOTAL)
			{
				System.out.println("\nGame over. Computer took " + turnsTaken + " turns to reach 20 points.");
				turnsTaken = 0;
				average = totalTurns/simTotal;
				simTotal++;
				player2Score = 0;
				
				if (simTotal > 10){	
					gameActive = false;
					playerState = true;
					average = totalTurns/simTotal;
					System.out.println();
					System.out.printf("\nSimulation over. Computer ");
					System.out.printf("averaged %.2f", average);
					System.out.print(" turns to reach 20 points.");
					break;
				}
				gameActive = true;
				break;
			}
			
		} //end of game while loop
	} //end of simulator for loop
	}//end of main
}// end of class
/* My strategy for the computer was to try to lower the amount of times "1" is rolled.
 * In order to accomplish this I decided that making the computer stop when it had 
 * more than 10 for a turn total would be a good idea. I made the computer a bit risky so that
 * it would be able to get a score of 20 within 2 turns. I figured that the risk was worth it because
 * the chances of rolling a "1" is 1 in 6.
 */
